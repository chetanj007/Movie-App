﻿using MovieApp.Models;
using System;
using System.Linq;

namespace MovieApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int input;
            var db = new EFContext();            

            while (true)
            {
                Console.WriteLine("\nSelect one option \n
                (1) Add Movie\n
                (2) Delete Movie \n
                (3) Add Actor\n
                (4) Delete Actor\n
                (5) View Movies List\n
                (6) View Actors List\n
                (7) Assign Movie\n
                (8) Exit ");


                input = Convert.ToInt32(Console.ReadLine());
                switch(input)
                {
                    case 1:
                        Console.Write("Enter Movie Name : ");
                        string name = Console.ReadLine();

                        var isAdded = db.Movies.Where(t => t.MovieName == name);
                        if (isAdded.Count() >= 1)
                        {
                            Console.WriteLine("This movie is already present");
                        }
                        else
                        {
                            Console.Write("\nEnter Movie Producer");
                            string producer = Console.ReadLine();
                            Console.Write("\nEnter Movie Duration");
                            int duration = Convert.ToInt32(Console.ReadLine());
                            Console.Write("\nEnter Movie Type");
                            string type = Console.ReadLine();
                            Movie movie = new Movie(name,producer,duration,type);
                            try
                            {
                                db.Movies.Add(movie);
                                db.SaveChanges();
                                Console.WriteLine("Successfully added");
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        }
                        break;


                    case 2:
                        Console.WriteLine("Enter movie name: ");
                        string movDel = Console.ReadLine();
                        var delMovie = db.Movies.Where(t => t.MovieName == movDel);

                        if (delMovie.Count() == 1)
                        {
                            try
                            {
                                db.Movies.Remove(db.Movies.Single(t => t.MovieName == movDel));
                                db.SaveChanges();
                                Console.WriteLine("Movie is removed !!");
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Choose Correct Movie Name");
                        }
                        break;


                    case 3:
                        Console.Write("Enter Actor Name : ");
                        string actName = Console.ReadLine();

                        var isActor = db.Actors.Where(t => t.ActorName == actName);

                        if (isActor.Count() >= 1)
                        {
                            Console.WriteLine("Actor is already present");
                        }
                        else
                        {                            
                            try
                            {
                                Console.Write("\nEnter Mobile number of Actor : ");
                                int mob =Convert.ToInt32( Console.ReadLine());
                                Console.Write("\nEnter emailId of Actor : ");
                                string email = Console.ReadLine();
                                Console.Write("\nEnter Gender of Actor: ");
                                string gen = Console.ReadLine();
                                Actor actor = new Actor(actName, mob,email,gen);
                                db.Actors.Add(actor);
                                db.SaveChanges();
                                Console.WriteLine("Actor Added successfully");
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }

                        }
                        break;

                       
                    case 4:
                        Console.WriteLine("Enter Actor name to delete : ");
                        string delAct = Console.ReadLine();
                        var delActor = db.Actors.Where(t => t.ActorName == delAct);

                        if (delActor.Count() == 1)
                        {
                            try
                            {
                                db.Actors.Remove(db.Actors.Single(t => t.ActorName == delAct));
                                db.SaveChanges();
                                Console.WriteLine("Actor deleted");
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Choose correct Movie");
                        }
                        break;


                    case 5:
                        var movieList = db.Movies;
                        try
                        {
                            foreach (var movie in movieList)
                            {
                                Console.WriteLine("Movie Name : " + movie.MovieName+" Movie Type : "+movie.Type);
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;


                    case 6:
                        var actorList = db.Actors;
                        try
                        {
                            foreach (var actor in actorList)
                            {
                                Console.WriteLine("Actor Name : " + actor.ActorName+" Actor Gender : "+actor.Gender);
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }
                        break;


                    case 7:
                        Console.Write("\nEnter Actor name");
                        var actorName = Console.ReadLine();
                        Console.Write("\nEnter Movie name");
                        var movieName = Console.ReadLine();
                        var isMovieAddedCount = db.Movies.Where(t => t.MovieName == movieName);
                        
                        var isActorAddedCount = db.Actors.Where(t => t.ActorName == actorName);
                        
                        if(isMovieAddedCount.Count()>=1 && isActorAddedCount.Count()>=1)
                        {
                            var isMovieAdded = db.Movies.First(t => t.MovieName == movieName);
                            var isActorAdded = db.Actors.First(t => t.ActorName == actorName);
                            MovActRelationship movActRelationship = new MovActRelationship(isMovieAdded.MovieId, isActorAdded.ActorId);
                            db.MovActRelationships.Add(movActRelationship);
                            db.SaveChanges();
                            Console.WriteLine("Actor is successfully assigned ");
                        }
                        else
                        {
                            Console.WriteLine("Movie or Actor is not present");
                        }

                        break;


                    case 8:
                        System.Environment.Exit(0);
                        break;                   
                }
            }
        }
    }
}
